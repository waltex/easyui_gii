document.write('\
\<link id="css_themes" rel="stylesheet" type="text/css" href="lib/easyui_1.5.1/themes/material/easyui.css">\
\<link rel="stylesheet" type="text/css" href="lib/easyui_1.5.1/themes/icon.css">\
\<script type="text/javascript" src="lib/easyui_1.5.1/jquery.min.js"></script>\
\<script type="text/javascript" src="lib/easyui_1.5.1/jquery.easyui.min.js"></script>\
\<script type="text/javascript" src="lib/easyui_1.5.1/locale/easyui-lang-it.js"></script>\
\
\<script src="lib/easyui_extension/datagrid-filter/datagrid-filter.js" type="text/javascript"></script>\
\<script src="lib/easyui_extension/datagrid-view/datagrid-groupview.js" type="text/javascript"></script>\
\<script src="lib/easyui_extension/datagrid-view/datagrid-detailview.js" type="text/javascript"></script>\
\<script src="lib/easyui_extension/datagrid-cellediting/datagrid-cellediting.js" type="text/javascript"></script>\
\<script src="lib/easyui_extension/edatagrid/jquery.edatagrid.js" type="text/javascript"></script>\
\
\<link rel="stylesheet" href="css/stile.css" type="text/css">\
\
\<link href="lib/easyui_extension/ribbon/ribbon-icon.css" rel="stylesheet" type="text/css"/>\
\<script src="lib/easyui_extension/ribbon/jquery.ribbon.js" type="text/javascript"></script>\
');