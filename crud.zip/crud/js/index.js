$(document).ready(function () {
    $('#dg1_reload').bind('click', function () {
        load_dg1();
    });
    $('#dg1_insert').bind('click', function () {
        //dg1_edit_form('insert');
    });
    $('#dg1_export').bind('click', function () {
        JSONToCSVConvertor($('#dg1').datagrid('getRows'), "dati", 'label')
    });
    function load_dg1() {
        //$('#tt').tabs('select', 'Tab1');
        $('#dg1').datagrid('uncheckAll');
        $('#dg1').datagrid('disableFilter');
        $('#dg1').edatagrid({
            border: false,
            toolbar: '#tb1',
            title: 'crud',
            //url: 'api/crud/ABB_CRUD/SELECT',
            //saveUrl: 'api/crud/ABB_CRUD/INSERT',
            //updateUrl: 'api/crud/ABB_CRUD/UPDATE',
            //destroyUrl: 'api/crud/ABB_CRUD/DELETE',
            method: 'post',
            rownumbers: true,
            striped: true,
            fit: false,
            idField: 'ID', /** importante **/
            singleSelect: true,
            checkOnSelect: false,
            selectOnCheck: false,
            remoteSort: false,
            multiSort: false,
            autoRowHeight: false, //For Speed refresh
            pagination: true,
            pageSize: 50,
            pageList: [25, 50, 100],

            destroyMsg: {
                norecord: {// when no record is selected
                    title: "Attenzione",
                    msg: "Non è stata selezionata nessuna riga"
                },
                confirm: {// when select a row
                    title: "Conferma",
                    msg: "Sei sicuro di voler cancellare?"
                }
            },
            onError: function (index, row) {
                $.messager.alert("Contattare assistenza", row.msg, 'error');
            },

            onAfterEdit: function (index, row) {
                $(this).edatagrid('updateRow', {
                    index: index,
                    row: {COMBO__TEXT: row.COMBO__TEXT, }
                });
            },
            onDblClickRow: function (index, row) {
                dg1_edit_form('update');
            },
            columns: [[
                    {field: 'ck', checkbox: true},
                    {field: 'ID', title: '#', sortable: true, hidden: true, },
                    {field: 'CAMPO1', title: 'CAMPO1', editor: {type: 'textbox', options: {required: true, }}, sortable: true, },
                    {field: 'COMBO', title: 'COMBO',
                        formatter: function (value, row, index)
                        {
                            return row.COMBO__TEXT;
                        },
                        editor: {type: 'combobox',
                            options: {
                                valueField: 'ID',
                                textField: 'DESCRI',
                                method: 'get',
                                url: 'api/data/combo_ABB_CRUD_COMBO.json',
                                required: true,
                                panelWidth: 250,

                                onSelect: function (record) {
                                    var index = $(this).closest('tr.datagrid-row').attr('datagrid-row-index');
                                    var row = $('#dg1').datagrid('getRows')[index];
                                    row['COMBO__TEXT'] = record.DESCRI
                                },

                            }},
                        sortable: true, },
                    {field: 'DTIN', title: 'Data Inizio', editor: {type: 'datebox', options: {formatter: myformatter_d_it, parser: myparser_d_it, required: true, }}, sortable: true, },
                    {field: 'DTFI', title: 'Data Fine', editor: {type: 'datebox', options: {formatter: myformatter_d_it, parser: myparser_d_it, required: true, }}, sortable: true, },
                    {field: 'ATTIVO', title: 'Attivo', editor: {type: 'checkbox', options: {on: '1', off: '0'}}, formatter: mycheck, required: true, sortable: true, },
                    {field: 'ID2', title: 'ID2', editor: {type: 'numberbox', options: {required: true, }}, sortable: true, },
                ]],

        });
        $('#dg1').datagrid('enableFilter');
    }

    load_dg1();


});
function dg1_edit_form(type) {
    $('#dg1_COMBO1').textbox({
        required: true,
    });

    var dlg_msg = $.messager.alert({
        id: 'dg1_edit',
        title: 'modifica',
        with : 450,
        height: 450,
        maximizable: true,
        resizable: true,
        buttons: [{
                text: 'Salva',
                iconCls: 'icon-save',
                onClick: function () {
                    $.messager.progress();	// display the progress bar
                    $('#dg1_fm').form('submit');
                }
            }, {
                text: 'Annulla',
                onClick: function () {
                    $(dlg_msg).panel('close');
                }
            }]
    });
    $("div:not([class]):contains('undefined')").remove();

    var input_cel = '<form id="fm">\n\
                        <div style="margin-top:5px"><input id="dg1_CAMPO1" name="CAMPO1">\n\
                        <div style="margin-top:5px"><input id="dg1_COMBO">\n\
                    </form>';
    dlg_msg.find('div').end().append(input_cel);
    $('#dg1_COMBO').combobox({
        data: null,
        mode: 'local',
        name: 'COMBO',
        valueField: 'FIELD',
        textField: 'TITLE',
        required: true,
        panelWidth: 300,
        editable: true,
        prompt: 'seleziona',
        label: 'Colonna:',
        labelPosition: 'left',
        width: 240,
    });
    $('#dg1_CAMPO1').textbox({
        editable: true,
        required: true,
        name: 'CAMPO1',
        prompt: 'ss',
        label: 'Valore:',
        labelPosition: 'left',
        width: 240,
    });
    if (type == "update") {
        var row = $('#dg1').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
        }
        $('#fm').form({url: 'api/update'})
    } else {
        $('#fm').form({url: 'api/insert'})
    }
    $('#fm').form({
        onSubmit: function () {
            var isValid = $(this).form('validate');
            if (!isValid) {
                $.messager.progress('close');	// hide progress bar while the form is invalid
            }
            return isValid;	// return false will stop the form submission
        },
        success: function () {
            $.messager.progress('close');	// hide progress bar while submit successfully
        }
    });
}