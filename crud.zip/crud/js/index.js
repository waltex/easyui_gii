$(document).ready(function () {
    $('#dg1_reload').bind('click', function () {
        load_dg1();
    });
    $('#dg1_export').bind('click', function () {
        JSONToCSVConvertor($('#dg1').datagrid('getRows'), "dati", 'label')
    });
    function load_dg1() {
        //$('#tt').tabs('select', 'Tab1');
        $('#dg1').datagrid('uncheckAll');
        $('#dg1').datagrid('disableFilter');
        $('#dg1').edatagrid({
            border: false,
            toolbar: '#tb1',
            title: 'crud',
            url: 'api/crud/ABB_CRUD/SELECT',
            saveUrl: 'api/crud/ABB_CRUD/INSERT',
            updateUrl: 'api/crud/ABB_CRUD/UPDATE',
            destroyUrl: 'api/crud/ABB_CRUD/DELETE',
            method: 'post',
            rownumbers: true,
            striped: true,
            fit: false,
            idField: 'ID', /** importante **/
            singleSelect: true,
            checkOnSelect: false,
            selectOnCheck: false,
            remoteSort: false,
            multiSort: false,
            autoRowHeight: false, //For Speed refresh
            pagination: true,
            pageSize: 50,
            pageList: [25, 50, 100],

            destroyMsg: {
                norecord: {// when no record is selected
                    title: "Attenzione",
                    msg: "Non è stata selezionata nessuna riga"
                },
                confirm: {// when select a row
                    title: "Conferma",
                    msg: "Sei sicuro di voler cancellare?"
                }
            },
            onError: function (index, row) {
                $.messager.alert("Contattare assistenza", row.msg, 'error');
            },

            onAfterEdit: function (index, row) {
                $(this).edatagrid('updateRow', {
                    index: index,
                    row: {COMBO__TEXT: row.COMBO__TEXT, }
                });
            },

            columns: [[
                    {field: 'ck', checkbox: true},
                    {field: 'ID', title: '#', sortable: true, hidden: true, },
                    {field: 'CAMPO1', title: 'CAMPO1', editor: {type: 'textbox', options: {required: true, }}, sortable: true, },
                    {field: 'COMBO', title: 'COMBO',
                        formatter: function (value, row, index)
                        {
                            return row.COMBO__TEXT;
                        },
                        editor: {type: 'combobox',
                            options: {
                                valueField: 'ID',
                                textField: 'DESCRI',
                                method: 'get',
                                url: 'api/data/combo_ABB_CRUD_COMBO.json',
                                required: true,
                                panelWidth: 250,

                                onSelect: function (record) {
                                    var index = $(this).closest('tr.datagrid-row').attr('datagrid-row-index');
                                    var row = $('#dg1').datagrid('getRows')[index];
                                    row['COMBO__TEXT'] = record.DESCRI
                                },

                            }},
                        sortable: true, },
                    {field: 'DTIN', title: 'Data Inizio', editor: {type: 'datebox', options: {formatter: myformatter_d_it, parser: myparser_d_it, required: true, }}, sortable: true, },
                    {field: 'DTFI', title: 'Data Fine', editor: {type: 'datebox', options: {formatter: myformatter_d_it, parser: myparser_d_it, required: true, }}, sortable: true, },
                    {field: 'ATTIVO', title: 'Attivo', editor: {type: 'checkbox', options: {on: '1', off: '0'}}, formatter: mycheck, required: true, sortable: true, },
                    {field: 'ID2', title: 'ID2', editor: {type: 'numberbox', options: {required: true, }}, sortable: true, },
                ]],

        });
        $('#dg1').datagrid('enableFilter');
    }

    load_dg1();


});
function dg1_open_form() {
    $('#dg1_COMBO1').textbox({
        required: true,
    });

    var dlg_msg = $.messager.alert({
        id: 'dg1_edit',
        title: 'modifica',
        //msg: 'Please enter your name:',
        /*
         fn: function (r) {
            if (r === undefined) {
                //console.log('press cancel');
            } else {

            }

        },
        */
        with : 450,
        height: 450,
        maximizable: true,
        closable: false,
        resizable: true,
        buttons: [{
                text: 'Salva',
                iconCls: 'icon-save',
                onClick: function () {
                    console.log('button1');
                }
            }, {
                text: 'Button2',
                onClick: function () {
                    console.log('button2');
                }
            }]
    });
    $("div:not([class]):contains('undefined')").remove();

    /*
    dlg_msg.find('.messager-input').numberspinner({
        required: false,
        label: 'ID',
        labelPosition: 'left',
        width: 130,
    }).attr('id', 'dg1_ID');
    */

    var input_cel = '<div style="margin-top:5px"><input id="dg1_CAMPO1"><div style="margin-top:5px"><input id="dg1_COMBO">';
    dlg_msg.find('div').end().append(input_cel);
    $('#dg1_COMBO').combobox({
        data: null,
        mode: 'local',
        valueField: 'FIELD',
        textField: 'TITLE',
        required: true,
        panelWidth: 300,
        editable: false,
        prompt: 'seleziona',
        label: 'Colonna:',
        labelPosition: 'left',
        width: 240,
    });
    $('#dg1_CAMPO1').textbox({
        editable: true,
        required: true,
        prompt: 'ss',
        label: 'Valore:',
        labelPosition: 'left',
        width: 240,
    });

}