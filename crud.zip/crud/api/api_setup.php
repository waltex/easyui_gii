<?php

$debug = true;
$debug_log_mb = 1; //max megabyte logs, -1 no limite
$api_log_mb = 1; //max megabyte logs, -1 no limite
$error_log_mb = 1; //max megabyte logs, -1 no limite

$db4_user='CENTEST';
$db4_psw='CENTEST';
$GOLD='  (DESCRIPTION =     (ADDRESS_LIST =       (ADDRESS = (PROTOCOL = TCP)(HOST = 192.168.20.42)(PORT = 1521))     )     (CONNECT_DATA =       (SID = GOLDTEST)       (SERVER = DEDICATED)     )   )';

