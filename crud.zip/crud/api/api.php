<?php

if (function_exists('xdebug_disable')) {
    xdebug_disable();
}

require '../vendor/autoload.php';

$app = new Slim\Slim();

//Add the middleware globally
$app->add(new \SlimJson\Middleware(array(
    'json.status' => false,
    'json.override_error' => true,
    'json.override_notfound' => true,
    'json.debug' => false,
    'json.cors' => true
)));


$app->post('/crud/ABB_CRUD/:command', 'crud_ABB_CRUD'); 


include 'fn_api.php';
$app->run();



/**
 * Crud  generate
 */
 function crud_ABB_CRUD ($command) {
 try {
        $app = Slim\Slim::getInstance();
        include 'api_setup.php';

        if ($command == 'SELECT') {

            $sql = "
            SELECT A.ID, A.CAMPO1, A.COMBO, TO_CHAR(A.DTIN,'DD-MM-YYYY') DTIN, TO_CHAR(A.DTFI,'DD-MM-YYYY') DTFI, A.ATTIVO, A.ID2 FROM ABB_CRUD A
            ";

            if ($debug) {
                error_log(LogTime() . ' Sql, crud select ABB_CRUD: ' . PHP_EOL . $sql . PHP_EOL, 3, 'debug.log');
            }

            $conn = oci_connect($db4_user, $db4_psw, $GOLD, 'UTF8');
            $db = oci_parse($conn, $sql);
            $rs = oci_execute($db);

            oci_fetch_all($db, $data, null, null, OCI_ASSOC + OCI_FETCHSTATEMENT_BY_ROW);

            $combo1 = combo_ABB_CRUD_COMBO();
$data = add_col_combo($combo1, $data, "COMBO", "ID", "DESCRI");


            $app->response()->body(json_encode($data));

    }

        if ($command == 'DELETE') {
            //retun lower id
            $ID = $app->request->params('id'); // Param from Post user

            $sql = "DELETE FROM ABB_CRUD WHERE ID IN ($ID)";
            
            if ($debug) {
                error_log(LogTime() . ' Sql, crud delete ABB_CRUD: ' . PHP_EOL . $sql . PHP_EOL, 3, 'debug.log');
            }

            $conn = oci_connect($db4_user, $db4_psw, $GOLD, 'UTF8');
            $db = oci_parse($conn, $sql);

            $rs = oci_execute($db);
            $app->render(200, ['success' => true, 'rows affected' => oci_num_rows($db)]);
        }

        if ($command == 'UPDATE') {
                        $ID = $app->request->params('ID'); // Param from Post user
$CAMPO1= $app->request->params('CAMPO1'); // Param from Post user
$COMBO= $app->request->params('COMBO'); // Param from Post user
$DTIN= $app->request->params('DTIN'); // Param from Post user
$DTFI= $app->request->params('DTFI'); // Param from Post user
$ATTIVO= $app->request->params('ATTIVO'); // Param from Post user
$ID2= $app->request->params('ID2'); // Param from Post user

            
            $parm_sql = [
                                ':ID' => $ID,
':CAMPO1' => $CAMPO1,
':COMBO' => $COMBO,
':DTIN' => $DTIN,
':DTFI' => $DTFI,
':ATTIVO' => $ATTIVO,
':ID2' => $ID2,

            ];

            $sql = "
                     UPDATE ABB_CRUD SET CAMPO1=:CAMPO1, COMBO=:COMBO, DTIN=TO_DATE(:DTIN,'DD-MM-YYYY'), DTFI=TO_DATE(:DTFI,'DD-MM-YYYY'), ATTIVO=:ATTIVO, ID2=:ID2 WHERE ID=:ID
                 ";

            if ($debug) {
                if (isset($parm_sql) & isset($sql)) {
                    error_log(LogTime() . 'update ABB_CRUD, sql: ' . PHP_EOL . print_r($parm_sql, true) . PHP_EOL . $sql . PHP_EOL, 3, 'debug.log');
                }
            }

            $conn = oci_connect($db4_user, $db4_psw, $GOLD, 'UTF8');
            $db = oci_parse($conn, $sql);
                        oci_bind_by_name($db, ":ID", $ID, -1);
oci_bind_by_name($db, ":CAMPO1", $CAMPO1, -1);
oci_bind_by_name($db, ":COMBO", $COMBO, -1);
oci_bind_by_name($db, ":DTIN", $DTIN, -1);
oci_bind_by_name($db, ":DTFI", $DTFI, -1);
oci_bind_by_name($db, ":ATTIVO", $ATTIVO, -1);
oci_bind_by_name($db, ":ID2", $ID2, -1);


            $rs = oci_execute($db);

            $data_r = [
                                'ID' => $ID,
'CAMPO1' => $CAMPO1,
'COMBO' => $COMBO,
'DTIN' => $DTIN,
'DTFI' => $DTFI,
'ATTIVO' => $ATTIVO,
'ID2' => $ID2,

            ];
            $app->response()->body(json_encode($data_r));
        }

        if ($command == 'INSERT') {
             
                        $CAMPO1= $app->request->params('CAMPO1'); // Param from Post user
$COMBO= $app->request->params('COMBO'); // Param from Post user
$DTIN= $app->request->params('DTIN'); // Param from Post user
$DTFI= $app->request->params('DTFI'); // Param from Post user
$ATTIVO= $app->request->params('ATTIVO'); // Param from Post user
$ID2= $app->request->params('ID2'); // Param from Post user


                        $sql = "
            
                        DECLARE
                        ID_SEQ NUMBER(15,0) := NULL;
                        BEGIN
                            SELECT ABB_CRUD_SEQ.NEXTVAL INTO ID_SEQ FROM DUAL;
                            INSERT INTO ABB_CRUD (ID, CAMPO1, COMBO, DTIN, DTFI, ATTIVO, ID2)
                            VALUES (ID_SEQ, :CAMPO1, :COMBO, TO_DATE(:DTIN,'DD-MM-YYYY'), TO_DATE(:DTFI,'DD-MM-YYYY'), :ATTIVO, :ID2)
                            RETURNING ID_SEQ  INTO :ID;
                        END;
                    
                   ";

            $parm_sql = [
                                ':CAMPO1' => $CAMPO1,
':COMBO' => $COMBO,
':DTIN' => $DTIN,
':DTFI' => $DTFI,
':ATTIVO' => $ATTIVO,
':ID2' => $ID2,

            ];

            if ($debug) {
                if (isset($parm_sql) & isset($sql)) {
                    error_log(LogTime() . 'insert ABB_CRUD, sql: ' . PHP_EOL . print_r($parm_sql, true) . PHP_EOL . $sql . PHP_EOL, 3, 'debug.log');
                }
            }


            $conn = oci_connect($db4_user, $db4_psw, $GOLD, 'UTF8');
            $db = oci_parse($conn, $sql);
                        oci_bind_by_name($db, ":ID", $ID, OCI_B_ROWID);
oci_bind_by_name($db, ":CAMPO1", $CAMPO1, -1);
oci_bind_by_name($db, ":COMBO", $COMBO, -1);
oci_bind_by_name($db, ":DTIN", $DTIN, -1);
oci_bind_by_name($db, ":DTFI", $DTFI, -1);
oci_bind_by_name($db, ":ATTIVO", $ATTIVO, -1);
oci_bind_by_name($db, ":ID2", $ID2, -1);


            $rs = oci_execute($db);
            $data_r = [
                                'ID' => $ID,
'CAMPO1' => $CAMPO1,
'COMBO' => $COMBO,
'DTIN' => $DTIN,
'DTFI' => $DTFI,
'ATTIVO' => $ATTIVO,
'ID2' => $ID2,

            ];
            $app->response()->body(json_encode($data_r));
        }
    } catch (Exception $e) {
        $app->render(200, ['isError' => true, 'msg' => $e->getMessage()]);
        error_log(LogTime() . ' errore - crud ABB_CRUD: ' . $e->getMessage() . PHP_EOL, 3, 'error.log');
    }
}



/**
 * combo for crud
 */
 function combo_ABB_CRUD_COMBO () {
 try {
        $app = Slim\Slim::getInstance();
        include 'api_setup.php';



            $sql = "
            SELECT ID, DESCRI from ABB_CRUD_COMBO 
            ";

            if ($debug) {
                error_log(LogTime() . ' Sql, combo select for crud ABB_CRUD_COMBO: ' . PHP_EOL . $sql . PHP_EOL, 3, 'debug.log');
            }

            $conn = oci_connect($db4_user, $db4_psw, $GOLD, 'UTF8');
            $db = oci_parse($conn, $sql);
            $rs = oci_execute($db);


            oci_fetch_all($db, $data, null, null, OCI_ASSOC + OCI_FETCHSTATEMENT_BY_ROW);

            $json = json_encode($data);
            file_put_contents("data/combo_ABB_CRUD_COMBO.json", $json);

            $app->response()->body(json_encode($data));

            return $data;


    } catch (Exception $e) {
        $app->render(200, ['isError' => true, 'msg' => $e->getMessage()]);
        error_log(LogTime() . ' errore - combo select for crud ABB_CRUD_COMBO: ' . $e->getMessage() . PHP_EOL, 3, 'error.log');
    }
}

